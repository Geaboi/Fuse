g++ main.cpp Wad.cpp -o test.out 
./test.out 