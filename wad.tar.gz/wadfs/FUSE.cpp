#define FUSE_USE_VERSION 26
#include <fuse.h>
#include <cstring>
#include <unistd.h>
#include <iostream>
#include <vector>
#include "../libWad/Wad.h"

Wad* wad = nullptr;

static int fs_getattr(const char* path, struct stat* stbuf) {
    memset(stbuf, 0, sizeof(struct stat));
    std::string p(path);

    if (wad->isDirectory(p)) {
        stbuf->st_mode = S_IFDIR | 0755;
        stbuf->st_nlink = 2;
        return 0;
    }

    if (wad->isContent(p)) {
        stbuf->st_mode = S_IFREG | 0644;
        stbuf->st_nlink = 1;
        stbuf->st_size = wad->getSize(p);
        return 0;
    }

    return -ENOENT;
}

static int fs_readdir(const char* path, void* buf, fuse_fill_dir_t filler,
                      off_t offset, struct fuse_file_info* fi) {
    filler(buf, ".", nullptr, 0);
    filler(buf, "..", nullptr, 0);

    std::string p(path);
    std::vector<std::string> contents;
    int ret = wad->getDirectory(p, &contents);
    if (ret < 0) return -ENOENT;

    for (const auto& entry : contents) {
        filler(buf, entry.c_str(), nullptr, 0);
    }

    return 0;
}



static int fs_read(const char* path, char* buf, size_t size, off_t offset,
                   struct fuse_file_info* fi) {
    std::string p(path);
    return wad->getContents(p, buf, size, offset);
}

static int fs_mkdir(const char* path, mode_t mode) {
    std::string p(path);
    wad->createDirectory(p);
    if (!wad->isDirectory(p)) return -EIO;
    return 0;
}

static int fs_mknod(const char* path, mode_t mode, dev_t rdev) {
    std::string p(path);
    wad->createFile(p);
    if (!wad->isContent(p)) return-ENOENT;
    return 0;
}

static int fs_open(const char *path, struct fuse_file_info *fi) {
    return 0;
}

static int fs_write(const char* path, const char* buf, size_t size, off_t offset, struct fuse_file_info* fi){
    std::string p(path);
    int written = wad->writeToFile(p, buf, size, offset);
    if (written < 0) return -EIO;
    return written;
}


static struct fuse_operations fs_oper;

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " <WAD file> <mount point>\n";
        return 1;
    }

    std::string wadPath = argv[argc - 2];
    if (wadPath.at(0) != '/') {
        wadPath = std::string(get_current_dir_name()) + "/" + wadPath;
    }

    wad = Wad::loadWad(wadPath);
    if (!wad) {
        std::cerr << "Failed to load WAD file.\n";
        return 1;
    }

    argv[argc - 2] = argv[argc - 1];
    argc--;

    fs_oper.getattr = fs_getattr;
    fs_oper.readdir = fs_readdir;
    fs_oper.open    = fs_open;
    fs_oper.read    = fs_read;  
    fs_oper.mknod   = fs_mknod;
    fs_oper.mkdir   = fs_mkdir;
    fs_oper.write   = fs_write;

    return fuse_main(argc, argv, &fs_oper, nullptr);
}
